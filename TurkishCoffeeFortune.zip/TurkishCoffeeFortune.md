# Turkish Coffee Fortune Teller — Full App Blueprint + Code

**Overview** Bu proje, kullanıcıların Türk kahvesi fincanı fotoğraflarını yükleyip kahve telvesi görüntülerinin makine öğrenmesiyle analiz edilip yorumlandığı mobil uygulamanın (Expo React Native) tam bir prototipini içerir. Uygulama ayrıca kredi sistemi, reklamla kredi kazanma akışı ve gerçek para ile kredi satın alma (Stripe) işlevlerini gösterir.

---

## 📂 Proje Klasör Yapısı

```
TurkishCoffeeFortune/
│
├── frontend/              # React Native (Expo) mobil uygulama
│   ├── App.js             # Ana uygulama dosyası
│   ├── package.json       # Frontend bağımlılıkları
│   └── ...
│
├── backend/               # Node.js + Express API
│   ├── server.js          # Sunucu kodu
│   ├── package.json       # Backend bağımlılıkları
│   └── uploads/           # Yüklenen fotoğraflar (geçici)
│
└── README.md              # Kurulum ve kullanım talimatları
```

---

## 📦 `frontend/package.json`

```json
{
  "name": "coffee-fortune-frontend",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "web": "expo start --web"
  },
  "dependencies": {
    "expo": "^51.0.0",
    "expo-image-picker": "~15.0.7",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "react-native": "0.74.0",
    "react-native-web": "~0.19.6"
  }
}
```

---

## 📦 `backend/package.json`

```json
{
  "name": "coffee-fortune-backend",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "@tensorflow-models/mobilenet": "^2.1.0",
    "@tensorflow/tfjs-node": "^4.16.0",
    "express": "^4.18.2",
    "multer": "^1.4.5",
    "stripe": "^14.0.0"
  }
}
```

---

## 🚀 Çalıştırma Talimatları

### 1. Repo’yu Klonla
```bash
git clone https://github.com/kullanici/coffee-fortune.git
cd coffee-fortune
```

### 2. Backend’i Başlat
```bash
cd backend
npm install
npm start
```

Backend `http://localhost:4000` adresinde çalışır.

### 3. Frontend’i Başlat
```bash
cd ../frontend
npm install
npm start
```

Expo açılacak, QR kod ile telefonundan test edebilirsin.

---

## ⚠️ Notlar

- Mobil emülatörde backend bağlantısı için `http://10.0.2.2:4000` kullan (Android Emulator).  
- Reklam entegrasyonu için gerçek AdMob/Unity Ads SDK eklenmeli.  
- Ödeme için Stripe veya in-app purchase entegrasyonu yapılmalı.  
- Model şu an `mobilenet` ile basit çalışıyor. Gerçek kahve telvesi görüntülerinden özel model eğitilmesi gerekir.

---

✅ Artık bu dosyaları direkt GitHub’a yükleyip çalıştırabilirsin.
